<?php

$resources = array(
); // end resources

$events[] =	array( 'event_name' => 'OnAfterDocumentFormLoad', 'method_name' => 'loadEditor');
$events[] =	array( 'event_name' => 'OnBeforeManagerHeadEnd', 'method_name' => 'loadScripts');

$version = "1.3"; // fixed an issue with editor not destroying

$module_name = "TinMCE Module"; // module Name used in admin nav
$module_description = "TinyMCE for documents"; // the description of your module
$admin_menu = false; // this tells the system that you have an admin section for your module, and will put it in the navigation in the manager
$author = "John Carlson <johncarlson21@gmail.com>"; // authors name

$module_key = 'mod_tinymce'; // the folder/module once extracted not used.. but this is what you would type into the input field to install

?>
