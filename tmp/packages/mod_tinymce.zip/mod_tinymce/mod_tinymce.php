<?php
class mod_tinymce extends etomite {
    var $classParams = array();
    var $modDir = '';
    
    public function __construct($params=array()) {
		parent::__construct();
        if (count($params) > 0) {
            $this->classParams = $params;
        }
        $this->modDir = dirname(__FILE__);
    }
    
    public function index() {
        echo "hello there from mod_test module";
        foreach ($this->classParams as $key=>$val) {
            echo "<p>param: " . $key . "=" . $val . "</p>";
        }
    }
    
    public function loadScripts() {
        $this->setJSCSS('<script type="text/javascript" src="/modules/mod_tinymce/includes/jscripts/tiny_mce/tiny_mce.js"></script>');
        $this->setJSCSS('<script type="text/javascript" src="/modules/mod_tinymce/views/editor.js"></script>');
        echo $this->headJSCSS;
    }
	
	public function loadEditor() {
	    echo "<script type='text/javascript'>
		if ($('#publishing #type').val() != 'reference' && $('#publishing #richtext').is(':checked')) {
	    	setToggle();
	    	setupTiny('taContent');
	    	setTimeout(function() {
    	    	$('#saveDocument').unbind('click', saveDocHandler);
    	    	$('#saveDocument').click(function() {
    	    		var is_tinyMCE_active = false;
					  if (tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
						is_tinyMCE_active = true;
					  }
                    if (is_tinyMCE_active) {
        	    		var ed = tinyMCE.get('taContent');
        	    		$('#taContent').val(ed.getContent());
        	    	}
    	    		Etomite.saveDocument();
    	    	});
				$('#saveCloseDocument').unbind('click');
				$('#saveCloseDocument').click(function() {
					var is_tinyMCE_active = false;
					  if (tinyMCE.activeEditor && !tinyMCE.activeEditor.isHidden()) {
						is_tinyMCE_active = true;
					  }
					if (is_tinyMCE_active) {
        	    		var ed = tinyMCE.get('taContent');
        	    		$('#taContent').val(ed.getContent());
        	    	}
					Etomite.saveDocument(true);
				});
    	    }, 2000);
		}
	    </script>";
	}
}
?>