function setupTiny(el) {
    tinyMCE.init({
      auto_reset_designmode : true,
      document_base_url : Etomite.db_url,
      mode : "exact",
      elements : el,
      theme : "advanced",
      relative_urls : Etomite.rel,
      remove_script_host : false,
      convert_urls : true,
      plugins : "autolink,lists,spellchecker,pagebreak,style,layer,table,save,advhr,advimage,advlink,emotions,iespell,inlinepopups,insertdatetime,preview,media,searchreplace,print,contextmenu,paste,directionality,noneditable,visualchars,nonbreaking,xhtmlxtras,template,fullscreen",
      theme_advanced_buttons1_add_before : "newdocument, separator",
      theme_advanced_buttons1_add : "fontselect, fontsizeselect",
      theme_advanced_buttons2_add : "separator, insertdate, inserttime, preview, separator, forecolor, backcolor",
      theme_advanced_buttons2_add_before: "cut, copy, paste, pastetext, pasteword, separator, search, replace, separator",
      theme_advanced_buttons3_add_before : "tablecontrols, separator",
      theme_advanced_buttons3_add : "emotions, iespell, media, advhr, separator, print, separator, ltr, rtl, separator, fullscreen",
      theme_advanced_toolbar_location : "top",
      theme_advanced_toolbar_align : "left",
      theme_advanced_path_location : "bottom",
      content_css : Etomite.cssPath,
      plugin_insertdate_dateFormat : Etomite.dateFormat,
      plugin_insertdate_timeFormat : Etomite.timeFormat,
      extended_valid_elements : "hr[class|width|size|noshade], font[face|size|color|style] ,span[class|align|style],module",
      //external_link_list_url : "example_data/example_link_list.js",
      //external_image_list_url : "example_data/example_image_list.js",
      //flash_external_list_url : "example_data/example_flash_list.js",
      file_browser_callback : 'elFinderBrowser',
      theme_advanced_resize_horizontal : false,
      theme_advanced_resizing : true,
      //init_instance_callback : resizeEditorBox,
      skin: "o2k7",
      skin_variant: 'silver'
    });
	
	// fixes the saveclose because it does not grab the correct content
	$('#saveCloseDocument').unbind('click');
	$('#saveCloseDocument').click(function() {
		tinymce.execCommand('mceToggleEditor',false,'taContent');
		Etomite.saveDocument(true);
	});
}

function setToggle() {

   $('#docContent').prepend('<a class="btn btn-primary" style="margin-bottom: 10px;" href="javascript:;" onclick="tinymce.execCommand(\'mceToggleEditor\',false,\'taContent\');">Toggle Editor</a>');

}